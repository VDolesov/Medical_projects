package ru.valdolesov.medicalapp

import io.flutter.embedding.android.FlutterActivity
 
class MainActivity: FlutterActivity() {
} 